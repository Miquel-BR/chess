            </div> <!-- #actualbody -->
        </div> <!-- #main -->
    </div> <!-- #wrap -->
    <footer>
        <div class="container_12">
            <div class="grid_12 clearfix">
                <p class="left">
                    Departament TIC de l'Ag&egrave;ncia d'Ecologia Urbana de BCN: CHESS SETUP
                </p>
                <p class="right">
                    &copy <a href="http://www.bcnecologia.net">BCNEcologia</a> 2016
                </p>
            </div>
        </div>
    </footer>
</body>
</html>