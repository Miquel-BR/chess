<?php
require_once("gestio_projectesBBDD.php");

class localitat {
	
public static function add($loc,$long,$lat)
	{
	}


}

?>