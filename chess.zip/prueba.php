<HTML>
        <H1>Probando Apache y PHP</H1>
        Salida del comando phpinfo:
	<?php
                     phpinfo();
        ?>      
 
</HTML>