<script type="text/javascript">
	function getComboA(idsel)
		{
		var value=idsel.value;
		}
	function addComboA(idsel,text)
		{
		//cuidado pq estamos llamando a la funci�n desde el radio y pasamos el id del radio, no el del combo
		var x = document.getElementById('idsel');
		var x2=document.createElement('SELECT');
		x2.id="combo";
		x2.name="combo2";
		//var opcionSeleccionada=x.selected_val;
		
		var opt = document.createElement('OPTION');
		
		opt.value = text;
		opt.text=text;
		//opt.innerHTML=text;
		
		
		x2.options[0]=opt;
		alert(text);
		x.options[0]=opt;
		alert(text);
		x2.disabled=true;
		//sel.submit.value="Consultar2";
		
		
		
		}
	function deshabilitarboton(sel)
		{
		sel.disabled=true;
		}
	function habilitarboton(sel)
		{
		sel.disabled=false;
		}

</script>