<?php

//validacionfrecuenciaanual.php;

require_once("../class/gestio_projectesBBDD.php");
//require_once("./class/usuari.php");
require_once("../class/distribuciofrecuencies.php");
//require_once("./scripts/jvscriptevents.php");
//require_once("./class/projecte.php");
gestio_projectesBBDD::setup();

if (isset($_POST['distribucio'])) {
	
	$distribucio=$_POST['distribucio'];
	//$valor=$_POST['valor'];
	$valor[1]=$_POST['gen'];
        $valor[2]=$_POST['feb'];
	$valor[3]=$_POST['mar'];
	$valor[4]=$_POST['apr'];
	$valor[5]=$_POST['mai'];
	$valor[6]=$_POST['jun'];
	$valor[7]=$_POST['jul'];
	$valor[8]=$_POST['ago'];
	$valor[9]=$_POST['sep'];
	$valor[10]=$_POST['oct'];
	$valor[11]=$_POST['nov'];
	$valor[12]=$_POST['dec'];
	$unitat=$_POST['unitats'];
	
}

//Ver si la frecuencia existe
$val=distribuciofrecuencies::validacio($distribucio);



if ($val>0)
	{
	
	//comprobar si existe la distribucion anual para cada mes con el idDistribucio_anual y mes;
	//encontrar si existe para cada mes idDistribucio;
	$mes=1;
	$iddistribucio=obteneriddistribucio($distribucio);

	while ($mes<=12)
		{
		//Si Existe para ese mes la distribucion anual
		$query="select count(*) from distribucions_anuals, tipus_distribucio where tipus_distribucio.id_distribucio=distribucions_anuals.idDistribucio_anual and mes='$mes' and nom_distribucio='$distribucio'";
		$result=mysql_query($query,gestio_projectesBBDD::$dbconn);
		$existe=$result;
		mysql_free_result($result);
		$valmes=$valor[$mes];
		if ($existe==0)
			{
			texto="$distribucio,$mes,$valmes";
			mensaje (texto);
			$sentencia = 'insert';
			$sentencia=$sentencia.' into distribucions_anuals (idDistribucio_anual,mes,valor) VALUES (';
			$sentencia=$sentencia.$distribucio.','.$mes.','.$valmes.')';
			$resultado=mysql_query($sentencia,gestio_projectesBBDD::$dbconn);
			mysql_free_result($resultado);
			}
		else {
			texto="$distribucio,$mes,$valmes";
			mensaje (texto);
			$query= 'UPDATE distribucions_anuals SET valor='.$valmes.' WHERE mes='.$mes.' and idDistribucio_anual='.$iddistribucio;
			$resultado2=mysql_query($query,gestio_projectesBBDD::$dbconn);
			//mysql_free_result($resultado2);
			}
		$mes++;
		}
	
	}
else
	{
	//a�adir distribucion;
	//distribuciofrecuencies::addtipofrecuencia($distribucio,$unitat);
	$query='select max('.$id_distribucio.') from tipus_distribucio';
	$result=mysql_query($query,gestio_projectesBBDD::$dbconn);
	if($result!=null){
		$i=$result+1;
		}
	else {
		$i=1;
		}
	mysql_free_result($result);
		
	$query='insert into tipus_distribucio (nom_distribucio,id_distribucio,unitat_distribucio) VALUES ('.$distribucio.','.$i.','.$unitat.')';
		
		
	$result=mysql_query($query,gestio_projectesBBDD::$dbconn);
	mysql_free_result($result);
	}


?>
<script type="text/javascript">

function mensaje(texto)
		{
		alert(texto);
		return "enviado";
		}
</script>
